const API_BASE_URL = 'http://localhost:3001';
const API_IMAGEM_PREFIX = '/view-image';

const carrosselWrapper = document.getElementById('carrossel-wrapper');
const contadorCarrinho = document.getElementById('contadorCarrinho');
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');
const itemMenuCadastros = document.getElementById("itemMenuCadastros");

function handleUserAction(action) {
  if (action === "sair") {
    logout();
  }
}


const path = require('path');

// ABRIR MENU

exports.abrirMenu = (req, res) => {

    const usuario = req.cookies.usuarioLogado;

    if (usuario) {

        res.sendFile(
            path.join(__dirname, '../../frontend/menu.html')
        );

    } else {

        res.redirect('/login/login.html');

    }

};


// REALIZAR LOGOUT

exports.logout = (req, res) => {

    res.clearCookie('usuarioLogado', {

        sameSite: 'Lax',

        secure: false,

        httpOnly: true,

        path: '/'

    });

    res.json({ status: 'deslogado' });

};


function atualizarContadorCarrinho() {
  const carrinho = JSON.parse(sessionStorage.getItem('carrinho')) || [];
  contadorCarrinho.textContent = carrinho.length;
}

function criarCardProduto(produto) {
  const card = document.createElement('div');
  card.classList.add('produto-card');

  const caminhoImagem = `${API_BASE_URL}${API_IMAGEM_PREFIX}/${produto.id_produto}`;
  const imagemPlaceholder = 'https://via.placeholder.com/200?text=Sem+Imagem';

  const precoFormatado = parseFloat(produto.preco_produto).toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  });

  card.innerHTML = `
    <img src="${caminhoImagem}" 
         alt="${produto.nome_produto}" 
         class="card-imagem"
         onerror="this.onerror=null; this.src='${imagemPlaceholder}';">
         
    <div class="card-titulo">${produto.nome_produto}</div>
    <div class="card-detalhe">ID: ${produto.id_produto}</div>
    <div class="card-detalhe">Estoque: ${produto.quantidade_estoque}</div>
    <div class="card-preco">${precoFormatado} / Kg</div>
    <div class="card-selecao-quantidade">
      <label for="qtd-${produto.id_produto}">Peso (g):</label>
      <input type="number" id="qtd-${produto.id_produto}" class="input-quantidade" value="100" min="10" step="10" data-produto-id="${produto.id_produto}">
    </div>
    <button class="btn-carrinho" data-produto-id="${produto.id_produto}">Adicionar ao Carrinho</button>
  `;
  return card;
}

function adicionarAoCarrinho(produtoId) {
  const inputQtd = document.querySelector(`.input-quantidade[data-produto-id="${produtoId}"]`);
  const quantidadeGramas = parseInt(inputQtd.value);

  if (isNaN(quantidadeGramas) || quantidadeGramas < 10) {
    alert('Por favor, insira uma quantidade válida (mínimo 10g).');
    return;
  }

  fetch(`${API_BASE_URL}/produto/${produtoId}`)
    .then(res => {
      if (!res.ok) throw new Error("Erro ao buscar produto");
      return res.json();
    })
    .then(produtoAPI => {
      const item = {
        id: produtoAPI.id_produto,
        nome: produtoAPI.nome_produto,
        preco: produtoAPI.preco_produto,
        quantidade: quantidadeGramas
      };

      let carrinho = JSON.parse(sessionStorage.getItem('carrinho')) || [];
      const existente = carrinho.find(i => i.id === item.id);

      if (existente) {
        existente.quantidade += quantidadeGramas;
      } else {
        carrinho.push(item);
      }

      sessionStorage.setItem('carrinho', JSON.stringify(carrinho));
      atualizarContadorCarrinho();
    })
    .catch((erro) => {
      console.error(erro);
      alert("Erro ao adicionar ao carrinho.");
    });
}

function renderizarProdutos(dados) {
  carrosselWrapper.innerHTML = '';

  const produtos = Array.isArray(dados) ? dados : (dados.products || []);

  if (produtos.length === 0) {
    carrosselWrapper.innerHTML = `<div class="mensagem-info">Nenhum produto encontrado.</div>`;
    return;
  }

  produtos.forEach(p => {
    const card = criarCardProduto(p);
    carrosselWrapper.appendChild(card);
  });

  document.querySelectorAll('.btn-carrinho').forEach(btn => {
    btn.addEventListener('click', e => adicionarAoCarrinho(e.target.dataset.produtoId));
  });
}

async function buscarProdutos() {
  try {
    const resposta = await fetch(API_BASE_URL + "/produto");

    if (!resposta.ok) {
      throw new Error("Erro na resposta da API");
    }

    const dados = await resposta.json();

    renderizarProdutos(dados);

  } catch (erro) {
    console.error("Erro ao carregar produtos:", erro);
    carrosselWrapper.innerHTML = `<div class="mensagem-info" style="color:red;">Erro ao carregar os produtos.</div>`;
  }
}

// ====== Controles do carrossel ======
prevBtn.addEventListener('click', () => {
  carrosselWrapper.scrollBy({ left: -300, behavior: 'smooth' });
});

nextBtn.addEventListener('click', () => {
  carrosselWrapper.scrollBy({ left: 300, behavior: 'smooth' });
});

// ====== Inicialização ======
window.onload = () => {
  // A ordem é importante: primeiro verifica a autorização para configurar o menu
  verificarAutorizacao(); 
  buscarProdutos();
  atualizarContadorCarrinho();
};