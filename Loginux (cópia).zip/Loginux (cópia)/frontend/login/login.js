
const API_BASE_URL = 'http://localhost:3001';

// ELEMENTOS HTML

const formEmail = document.getElementById('formEmail');
const formSenha = document.getElementById('formSenha');

const inputEmail = document.getElementById('email');
const inputSenha = document.getElementById('senha');

const mensagemErro = document.getElementById('mensagemErro');


// EVENTOS

formEmail.addEventListener('submit', verificarEmail);

formSenha.addEventListener('submit', realizarLogin);


// ETAPA 1: VERIFICAR EMAIL

async function verificarEmail(event) {

    event.preventDefault();

    const email = inputEmail.value.trim();

    if (!email.toLowerCase().endsWith('@gmail.com')) {
        alert('Informe um endereço Gmail válido.');
        return;
    }

    try {

        const response = await fetch(`${API_BASE_URL}/login/verificarEmail`, {

            method: 'POST',

            headers: {
                'Content-Type': 'application/json'
            },

            body: JSON.stringify({ email })

        });

        const data = await response.json();

        if (data.status === 'existe') {

            document.getElementById('nomeUsuario').innerText =
                `Olá, ${data.nome}`;

            mostrarCard('cardSenha');

        } else {

            const desejaCadastrar = confirm(
                'E-mail não encontrado. Deseja se cadastrar?'
            );

            if (desejaCadastrar) {

                document.getElementById('emailCadast').value = email;

                mostrarCard('cardCadastro');

            }

        }

    } catch (error) {

        console.error('Erro ao verificar email:', error);

        alert('Erro ao se comunicar com o servidor.');

    }

}


// ETAPA 2: REALIZAR LOGIN

async function realizarLogin(event) {

    event.preventDefault();

    const email = inputEmail.value.trim();
    const senha = inputSenha.value;

    mensagemErro.innerText = '';

    try {

        const response = await fetch(`${API_BASE_URL}/login/verificarSenha`, {

            method: 'POST',

            headers: {
                'Content-Type': 'application/json'
            },

            credentials: 'include',

            body: JSON.stringify({ email, senha })

        });

        const data = await response.json();

        if (data.status === 'ok') {

            window.location.href = '/menu';

        } else if (data.status === 'senha_incorreta') {

            mensagemErro.innerText =
                'Senha incorreta. Tente novamente.';

        } else {

            mensagemErro.innerText =
                'Erro ao efetuar login.';

        }

    } catch (error) {

        console.error('Erro ao realizar login:', error);

        mensagemErro.innerText =
            'Falha ao se comunicar com o servidor.';

    }

}


// ETAPA 3: CADASTRAR USUARIO

async function cadastrarUsuario() {

    const email = document.getElementById('emailCadast').value;
    const nome = document.getElementById('nameCadast').value.trim();
    const senha = document.getElementById('senhaCadast').value;

    if (!nome || !senha) {

        alert('Preencha todos os campos.');

        return;

    }

    try {

        const response = await fetch(`${API_BASE_URL}/login/cadastrar`, {

            method: 'POST',

            headers: {
                'Content-Type': 'application/json'
            },

            body: JSON.stringify({
                email,
                nome,
                senha
            })

        });

        const data = await response.json();

        if (data.status === 'ok') {

            alert('Cadastro realizado com sucesso!');

            mostrarCard('cardEmail');

            document.getElementById('nameCadast').value = '';
            document.getElementById('senhaCadast').value = '';

        } else {

            alert(data.mensagem || 'Erro ao realizar cadastro.');

        }

    } catch (error) {

        console.error('Erro ao cadastrar:', error);

        alert('Falha ao se comunicar com o servidor.');

    }

}


// MOSTRAR CARDS

function mostrarCard(idParaMostrar) {

    document.getElementById('cardEmail').classList.add('hidden');

    document.getElementById('cardSenha').classList.add('hidden');

    document.getElementById('cardCadastro').classList.add('hidden');

    document.getElementById(idParaMostrar).classList.remove('hidden');

}


// VOLTAR ENTRE AS ETAPAS

function voltarPara(idParaVoltar) {

    mensagemErro.innerText = '';

    inputSenha.value = '';

    mostrarCard(idParaVoltar);

}


// ESQUECI A SENHA

function esqueciSenha() {

    alert('A recuperação de senha ainda não foi implementada.');

}
